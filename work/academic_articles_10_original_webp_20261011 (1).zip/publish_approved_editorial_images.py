#!/usr/bin/env python3
"""Install ten approved original editorial images into the Bertina Git repository.
Does not push, deploy, touch secrets, or bypass existing tests.
Run inside the extracted image package copied into the site repository.
"""
import argparse,json,re,hashlib,sys
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--apply',action='store_true',help='Apply changes (without this, dry-run only)')
p.add_argument('--repo',type=Path,default=Path.cwd(),help='Git repository root')
a=p.parse_args();repo=a.repo.resolve();pkg=Path(__file__).resolve().parent
manifest=json.loads((pkg/'manifest.json').read_text(encoding='utf-8'))['images']
reg_path=repo/'assets/media-registry.json'
if not reg_path.exists():sys.exit('ERROR: run with --repo pointing to the site Git repository root')
registry=json.loads(reg_path.read_text(encoding='utf-8'))
changes=[]
checks=[]
for e in manifest:
 src=pkg/'assets/images/editorial-launch'/e['featured_image']
 if hashlib.sha256(src.read_bytes()).hexdigest()!=e['sha256']:sys.exit('ERROR: media SHA mismatch '+str(src))
 dest=repo/e['website_path'].lstrip('/')
 if dest.exists() and hashlib.sha256(dest.read_bytes()).hexdigest()!=e['sha256']:sys.exit('ERROR: destination already contains different image '+str(dest))
 if not dest.exists():changes.append(('binary',dest,src.read_bytes()))
 page=repo/'fa/akhbar'/e['article_slug']/'index.html'
 html=page.read_text(encoding='utf-8')
 img_match=re.search(r'<figure class="editorial-figure launch-hero-image"><img[^>]+\bsrc="([^"]+)"',html)
 if not img_match:sys.exit('ERROR: article hero not found '+str(page))
 old_src=img_match.group(1)
 new_src=e['website_path']
 if old_src!=new_src:
  if html.count(old_src)<1:sys.exit('ERROR: old hero reference absent')
  html=html.replace(old_src,new_src)
  html=html.replace('https://drjavadrezazadeh.com'+old_src,'https://drjavadrezazadeh.com'+new_src)
  # URLs in JSON-LD and OG are absolute and already updated by replacement above.
  new_tag=re.search(r'<figure class="editorial-figure launch-hero-image"><img[^>]+>',html)
  if not new_tag:sys.exit('ERROR: hero tag not found')
  tag=new_tag.group(0)
  tag=re.sub(r'\bwidth="\d+"','width="1672"',tag)
  tag=re.sub(r'\bheight="\d+"','height="941"',tag)
  tag=re.sub(r'\balt="[^"]*"','alt="'+e['alt_fa']+'"',tag)
  html=html.replace(new_tag.group(0),tag,1)
  html=re.sub(r'(<meta property="og:image:alt" content=")[^"]*(">)',lambda m:m.group(1)+e['alt_fa']+m.group(2),html,count=1)
  # When the same old image was reused as a bookstore sidebar image, correct declared dimensions too.
  html=re.sub(r'<img\b[^>]+>',lambda m:(re.sub(r'\bheight="\d+"','height="941"',re.sub(r'\bwidth="\d+"','width="1672"',m.group(0))) if new_src in m.group(0) else m.group(0)),html)
  changes.append(('text',page,html.encode('utf-8')))
 # Update only the matching news listing card, not unrelated article cards using old image.
 index=repo/'fa/akhbar/index.html'
 indexes=checks
 checks.append((e,old_src,new_src))
 rel=e['website_path'].lstrip('/')
 if rel not in [x.get('path') for x in registry.get('assets',[])]:
  registry['assets'].append({'path':rel,'kind':'editorial-photography','role':'academic-news-featured','mime_type':'image/webp','width':1672,'height':941,'source_status':'production-source','provenance':'Owner-created ten-image academic editorial launch collection, 2026-10-11','optimization_profile':'knowledge-featured','rights':'site-use-approved by owner','alt_en':'Original conceptual editorial visual for '+e['article_slug'].replace('-',' '),'alt_fa':e['alt_fa'],'caption_en':'Owner-approved original featured image for the academic editorial launch.','caption_fa':e['alt_fa']})
index=repo/'fa/akhbar/index.html'
s=index.read_text(encoding='utf-8')
for e,old_src,new_src in checks:
 slug=e['article_slug'];rg=re.compile(r'(<a class="news-card" href="\./'+re.escape(slug)+r'/">)(.*?)(</a>)',re.S)
 hit=rg.search(s)
 if not hit:sys.exit('ERROR: news card missing for '+slug)
 content=hit.group(2).replace(old_src,new_src)
 content=re.sub(r'<img\b[^>]+>',lambda m:(re.sub(r'\bheight="\d+"','height="941"',re.sub(r'\bwidth="\d+"','width="1672"',m.group(0))) if new_src in m.group(0) else m.group(0)),content,count=1)
 s=s[:hit.start(2)]+content+s[hit.end(2):]
# Collection-page social image now follows the academic ecosystem featured image.
featured=manifest[0]
s=re.sub(r'(<meta property="og:image" content=")[^"]*(">)',lambda m:m.group(1)+'https://drjavadrezazadeh.com'+featured['website_path']+m.group(2),s,count=1)
s=re.sub(r'(<meta name="twitter:image" content=")[^"]*(">)',lambda m:m.group(1)+'https://drjavadrezazadeh.com'+featured['website_path']+m.group(2),s,count=1)
changes.append(('text',index,s.encode('utf-8')))
changes.append(('text',reg_path,(json.dumps(registry,ensure_ascii=False,indent=2)+'\n').encode('utf-8')))
print('Validated',len(manifest),'original images; planned files:',len(changes))
for kind,dest,_ in changes:print(' ',kind,dest.relative_to(repo))
if not a.apply:
 print('\nDRY RUN ONLY. Rerun with --apply after reviewing the file list.')
else:
 for kind,dest,content in changes:
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content)
 print('\nInstalled locally. Run node scripts/media-library-audit.mjs and node scripts/audit-13-articles.mjs and your CI suite before committing or deploying.')
