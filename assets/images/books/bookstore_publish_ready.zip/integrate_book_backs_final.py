"""Run only in canonical repository root. No payment, inventory, or deploy changes."""
from pathlib import Path
import json, zipfile
root=Path.cwd(); archive=Path(__file__).with_name('bookstore_back_covers_final.zip')
cat=root/'assets/data/book-catalog.json'; js=root/'assets/js/book-store.js'
assert cat.is_file() and js.is_file()
data=json.loads(cat.read_text()); books={b['id']:b for b in data['books']}
assert books['roshanaei']['title_fa']=='سپیدی'
files={'roshanaei':'sepidi-back-1200.webp','tariki':'tariki-back-1200.webp','bonbast':'bonbast-back-1200.webp'}
with zipfile.ZipFile(archive) as z:
 for bid,fn in files.items():
  p=root/'assets/images/books'/fn;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(fn))
  books[bid]['bibliography']['back_cover_image']='/assets/images/books/'+fn
s=js.read_text();needle=" const API='/api';"
helper=''' function bookBackUrl(book){
  const path=String(book?.bibliography?.back_cover_image||'');
  return /^\\/assets\\/images\\/books\\/[a-z0-9][a-z0-9._-]*\\.(?:avif|webp|png|jpe?g)$/i.test(path)?root(path):null;
 }
'''
assert needle in s
if 'function bookBackUrl(' not in s:s=s.replace(needle,helper+needle)
needle2='  host.innerHTML=\'<div class="book-detail-layout">\'+detailCover+'
replacement='''  const backSrc=bookBackUrl(b);
  const backCover=backSrc?'<figure class="book-cover book-back-cover"><img src="'+escapeHtml(backSrc)+'" width="900" height="600" loading="lazy" decoding="async" alt="'+escapeHtml(isFa?'پشت جلد کتاب «'+b.title_fa+'»':'Back cover of '+b.english_reference_title)+'"></figure>':'';
  host.innerHTML='<div class="book-detail-layout">'+detailCover+backCover+'''
assert needle2 in s
if 'const backSrc=bookBackUrl(b)' not in s:s=s.replace(needle2,replacement)
js.write_text(s);cat.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print('Integrated 3 back covers. Run tests and deploy through approved Bertina workflow.')
